﻿public interface IAddOperation
{
    bool AddEmployeeDetails(Employee employee); // Method to add employee details
}
