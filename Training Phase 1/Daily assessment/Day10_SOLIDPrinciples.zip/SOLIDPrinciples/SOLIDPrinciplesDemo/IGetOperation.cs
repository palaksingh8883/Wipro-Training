﻿public interface IGetOperation
{
    bool ShowEmployeeDetails(int employeeId); // Method to show employee details by ID
}
