import UserList from "./UserList";

function App() {
  return (
    <div>
      <h1>Simple User Management</h1>
      <UserList />
    </div>
  );
}

export default App;
