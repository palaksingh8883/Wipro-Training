import { useState } from "react";

const UserForm = ({ onUserAdded }) => {
  const [name, setName] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name) return;

    fetch("http://localhost:5000/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: Date.now(), name }),
    })
      .then((response) => response.json())
      .then((newUser) => {
        onUserAdded(newUser);
        setName(""); // Clear input field
      })
      .catch((error) => console.error("Error adding user:", error));
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Enter name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <button type="submit">Add User</button>
    </form>
  );
};

export default UserForm;
